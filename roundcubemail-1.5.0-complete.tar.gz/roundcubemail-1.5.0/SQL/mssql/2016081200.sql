ALTER TABLE [dbo].[session] DROP CONSTRAINT [DF_session_created]
GO

ALTER TABLE [dbo].[session] DROP COLUMN [created]
GO
